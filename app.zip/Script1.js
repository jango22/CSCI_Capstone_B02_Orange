var sql = require(�mssql�);

var config = {

user: �orangeteamadmin�,
password: �AevhKutuIA7luKby4JZV�,
server: �csci2999b02.cps316w6axpe.us-east-1.rds.amazonaws.com�,
database: �csci2999b02�

}